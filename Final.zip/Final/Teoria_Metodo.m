function prediccion_futbol()

   % Equipos disponibles
    equipos = {'Argentina', 'Brasil', 'Uruguay', 'Colombia', 'Perú', 'Chile', 'Ecuador', 'Paraguay', 'Venezuela', 'Bolivia'};

    equipos_csv = {'Argentina.csv', 'Brasil.csv', 'Chile.csv', 'Colombia.csv', 'Ecuador.csv', 'Paraguay.csv', 'Peru.csv', 'Uruguay.csv', 'Venezuela.csv', 'Bolivia.csv'};

    datos_equipos = cell(1, length(equipos_csv));
    for i = 1:length(equipos_csv)
        datos_equipos{i} = readtable(equipos_csv{i});
    end

    % Datos del primer tiempo
    equipo1_idx = input('Ingrese el índice del primer equipo (1-10): ');
    equipo2_idx = input('Ingrese el índice del segundo equipo (1-10): ');

    tiros1_PT = input('Tiros al arco del equipo 1 en el primer tiempo: ');
    goles1_PT = input('Goles del equipo 1 en el primer tiempo: ');
    tiros2_PT = input('Tiros al arco del equipo 2 en el primer tiempo: ');
    goles2_PT = input('Goles del equipo 2 en el primer tiempo: ');
    faltas1_PT = input('Faltas del equipo 1 en el primer tiempo: ');
    faltas2_PT = input('Faltas del equipo 2 en el primer tiempo: ');
    exp1_PT = input('Expulsiones del equipo 1 en el primer tiempo: ');
    exp2_PT = input('Expulsiones del equipo 2 en el primer tiempo: ');

    % Acceder a los datos de los equipos seleccionados
    datos_equipo1 = datos_equipos{equipo1_idx};
    datos_equipo2 = datos_equipos{equipo2_idx};

    % Obtener los nombres de los equipos seleccionados
    equipo1 = equipos{equipo1_idx};
    equipo2 = equipos{equipo2_idx};

    % Mostrar los equipos seleccionados
    fprintf('Equipos seleccionados:\n');
    fprintf('Equipo 1: %s\n', equipo1);
    fprintf('Equipo 2: %s\n', equipo2);



    % Parámetros del modelo (ajustables)
    k1 = 0.1; % Tasa de conversión de tiros a goles
    k2 = 0.05; % Ajustar según sea necesario
    k3 = 0.2; % Ajustar según sea necesario
    k4 = 0.01; % Ajustar constante del resorte
    energia_equilibrio = 5; % Ajustar valor de equilibrio (ejemplo)


    % Condiciones iniciales
    t0 = 45; % Inicio del segundo tiempo
    y0 = goles1_PT - goles2_PT; % Diferencia de goles al inicio del segundo tiempo
    tf = 90; % Fin del partido
    tiempos_sustituciones = [60, 75];
    energia1 = 0;
    energia2 = 0;

    % Función para la ecuación diferencial
    function dydt = goles(t, y, tiros1, tiros2, faltas1, faltas2, exp1, exp2, energia1, energia2)
        % Actualizar energía durante el juego
        % Buscar si hay una sustitución en este momento
        idx = find(tiempos_sustituciones == t);
        if ~isempty(idx)
            energia1 = energia1 + recuperacion_sustitucion;
        end

    % Calcular dydt usando tus ecuaciones (ejemplo simplificado)
        dydt = k1 * (tiros1 - tiros2) + k2 * (faltas1 - faltas2) + k3 * (exp1 - exp2);
    end

    % Resolver la ecuación diferencial
    try
        [t, y] = ode45(@(t,y) goles(t, y, tiros1_PT, tiros2_PT, faltas1_PT, faltas2_PT, ...
                                 exp1_PT, exp2_PT, energia1, energia2), [t0, tf], y0);
    catch ME
        disp('Error durante la resolución del ODE:');
        disp(ME.message);
        return;
    end

    % Calcular los goles finales
    goles_finales1 = goles1_PT + y(end);
    goles_finales2 = goles2_PT - y(end);

    % Mostrar resultado
    fprintf('Resultado final:\n');
    fprintf('Equipo 1: %d goles\n', goles_finales1);
    fprintf('Equipo 2: %d goles\n', goles_finales2);
end
