function prediccion_futbol()
    % Datos del primer tiempo
    tiros1_PT = input('Tiros al arco del equipo 1 en el primer tiempo: ');
    goles1_PT = input('Goles del equipo 1 en el primer tiempo: ');
    tiros2_PT = input('Tiros al arco del equipo 2 en el primer tiempo: ');
    goles2_PT = input('Goles del equipo 2 en el primer tiempo: ');
    faltas1_PT = input('Faltas del equipo 1 en el primer tiempo: ');
    faltas2_PT = input('Faltas del equipo 2 en el primer tiempo: ');
    exp1_PT = input('Expulsiones del equipo 1 en el primer tiempo: ');
    exp2_PT = input('Expulsiones del equipo 2 en el primer tiempo: ');


    % Parámetros del modelo (ajustables)
    k1 = 0.1; % Tasa de conversión de tiros a goles
    k2 = 0.05; % Ajustar según sea necesario
    k3 = 0.2; % Ajustar según sea necesario

    % Condiciones iniciales
    t0 = 45; % Inicio del segundo tiempo
    y0 = goles1_PT - goles2_PT; % Diferencia de goles al inicio del segundo tiempo
    tf = 90; % Fin del partido

    % Función para la ecuación diferencial
    function dydt = goles(t, y, tiros1, tiros2, faltas1, faltas2, exp1, exp2)

    % Calcular dydt usando tus ecuaciones (ejemplo simplificado)
        dydt = k1 * (tiros1 - tiros2) + k2 * (faltas1 - faltas2) + k3 * (exp1 - exp2);
    end

    % Resolver la ecuación diferencial
    try
        [t, y] = ode45(@(t,y) goles(t, y, tiros1_PT, tiros2_PT, faltas1_PT, faltas2_PT, ...
                                 exp1_PT, exp2_PT), [t0, tf], y0);
    catch ME
        disp('Error durante la resolución del ODE:');
        disp(ME.message);
        return;
    end

    % Calcular los goles finales
    goles_finales1 = goles1_PT + y(end);
    goles_finales2 = goles2_PT - y(end);

    % Mostrar resultado
    fprintf('Resultado final:\n');
    fprintf('Equipo 1: %d goles\n', goles_finales1);
    fprintf('Equipo 2: %d goles\n', goles_finales2);
end
