% Equipos de Copa America
equipos = {'Argentina', 'Bolivia', 'Brasil', 'Chile', 'Colombia', 'Ecuador', 'Paraguay', 'Peru', 'Uruguay', 'Venezuela'};

% Seleccion de equipos rivales
equipo1 = input('Ingrese el índice del primer equipo (1-10): ');
equipo2 = input('Ingrese el índice del segundo equipo (1-10): ');

% Nombre de los equipos seleccionados
equipoU = equipos{equipo1};
equipoD = equipos{equipo2};

% Transicion - tiempo - eventos
tiempo_total = 90;
reloj_virtual = 0;
eventos = [];
eventos_str = {};

% Limites de goles y faltas
num_goles = 5;  % Número de goles aleatorios en el segundo tiempo
num_tarjetas = 2;  % Número de tarjetas aleatorias en el segundo tiempo

% Ingreso de datos del primer tiempo
primer_tiempo = 45;
goles1_PT = input(['¿Cuántos goles anotó ', equipoU, ' en el primer tiempo? ']);
goles2_PT = input(['¿Cuántos goles anotó ', equipoD, ' en el primer tiempo? ']);
faltas1_PT = input(['¿Cuántas faltas tuvo ', equipoU, ' en el primer tiempo? ']);
faltas2_PT = input(['¿Cuántas faltas tuvo ', equipoD, ' en el primer tiempo? ']);

% Contadores con los valores ingresados
equipo1 = goles1_PT;
equipo2 = goles2_PT;
faltas_equipo1 = faltas1_PT;
faltas_equipo2 = faltas2_PT;

% Generar tiempos aleatorios para goles y tarjetas en el segundo tiempo
goles_tiempos = sort(randi([primer_tiempo+1 tiempo_total], 1, num_goles));
tarjetas_tiempos = sort(randi([primer_tiempo+1 tiempo_total], 1, num_tarjetas));

% Crear vectores para almacenar los goles por minuto
tiempo = 0:tiempo_total;
goles_equipo1 = zeros(1, tiempo_total+1);
goles_equipo2 = zeros(1, tiempo_total+1);

disp('Comienza el partido por pasar Modelo y Simulacion¡')

for t = 1:tiempo_total
    reloj_virtual = t;

    % Verificar si hay un gol en este minuto
    if ismember(reloj_virtual, goles_tiempos)
        if rand < 0.5
            equipo1 = equipo1 + 1;
            eventos = [eventos; reloj_virtual];
            eventos_str{end+1} = sprintf('Minuto %d: ¡gol para %s!', reloj_virtual, equipoU);
        else
            equipo2 = equipo2 + 1;
            eventos = [eventos; reloj_virtual];
            eventos_str{end+1} = sprintf('Minuto %d: ¡gol para %s!', reloj_virtual, equipoD);
        end
    end

    % Verificar si hay una tarjeta en este minuto
    if ismember(reloj_virtual, tarjetas_tiempos)
        if rand < 0.5
            eventos_str{end+1} = sprintf('Minuto %d: Tarjeta amarilla para %s', reloj_virtual, equipoU);
        else
            eventos_str{end+1} = sprintf('Minuto %d: Tarjeta amarilla para %s', reloj_virtual, equipoD);
        end
        eventos = [eventos; reloj_virtual];
    end

    % Actualizar los vectores de goles
    goles_equipo1(t+1) = equipo1;
    goles_equipo2(t+1) = equipo2;

    % Mensajes para el inicio y final de cada tiempo
    if reloj_virtual == 45
        eventos_str{end+1} = sprintf('Minuto 45: Final del primer tiempo.');
    elseif reloj_virtual == 90
        eventos_str{end+1} = sprintf('Minuto 90: Final del partido.');
    end
end

% Mostrar el resultado final y los eventos
disp('Resultado final:')
fprintf('%s: %d - %s: %d\n', equipoU, equipo1, equipoD, equipo2);

disp('Eventos durante el partido:')
for i = 1:length(eventos_str)
    disp(eventos_str{i});
end

% Graficar la evolución de los goles
figure;
plot(tiempo, goles_equipo1, '-o', 'LineWidth', 2, 'DisplayName', 'Equipo 1');
hold on;
plot(tiempo, goles_equipo2, '-x', 'LineWidth', 2, 'DisplayName', 'Equipo 2');
title('Evolución de goles');
xlabel('Minutos');
ylabel('Número de goles');
legend('show');
grid on;
hold off;